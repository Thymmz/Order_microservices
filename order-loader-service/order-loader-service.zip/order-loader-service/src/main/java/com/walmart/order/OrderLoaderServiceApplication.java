package com.walmart.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderLoaderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderLoaderServiceApplication.class, args);
	}

}
