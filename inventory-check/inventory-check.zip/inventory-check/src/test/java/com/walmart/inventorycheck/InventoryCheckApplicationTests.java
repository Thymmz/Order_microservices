package com.walmart.inventorycheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
