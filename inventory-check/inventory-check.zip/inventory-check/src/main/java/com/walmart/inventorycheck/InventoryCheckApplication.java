package com.walmart.inventorycheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryCheckApplication.class, args);
	}

}
