package com.walmart.apigatewayorders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
