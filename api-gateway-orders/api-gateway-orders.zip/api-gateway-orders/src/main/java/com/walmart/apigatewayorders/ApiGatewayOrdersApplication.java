package com.walmart.apigatewayorders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayOrdersApplication.class, args);
	}

}
