package com.walmart.ordercreateservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderCreateServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderCreateServiceApplication.class, args);
	}

}
