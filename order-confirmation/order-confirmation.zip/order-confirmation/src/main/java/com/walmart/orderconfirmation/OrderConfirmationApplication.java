package com.walmart.orderconfirmation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderConfirmationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderConfirmationApplication.class, args);
	}

}
