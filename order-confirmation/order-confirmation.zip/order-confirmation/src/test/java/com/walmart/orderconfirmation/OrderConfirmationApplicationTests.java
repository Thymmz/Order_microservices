package com.walmart.orderconfirmation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderConfirmationApplicationTests {

	@Test
	void contextLoads() {
	}

}
