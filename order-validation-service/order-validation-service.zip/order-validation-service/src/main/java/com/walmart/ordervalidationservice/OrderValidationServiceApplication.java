package com.walmart.ordervalidationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderValidationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderValidationServiceApplication.class, args);
	}

}
