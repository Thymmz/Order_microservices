package com.walmart.ordervalidationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderValidationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
