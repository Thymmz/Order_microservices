package com.walmart.invoicecreate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceCreateApplicationTests {

	@Test
	void contextLoads() {
	}

}
