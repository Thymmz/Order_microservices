package com.walmart.invoicecreate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoiceCreateApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoiceCreateApplication.class, args);
	}

}
